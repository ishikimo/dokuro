const commando = require('discord.js-commando');
const bot = new commando.Client({
	owner: '246017713015750656'
});


bot.on('ready', () => {
  bot.user.setGame('Type !help For Help!')
	console.log('Dokuro Is online!')
})

bot.registry.registerGroup('random', 'Dice');
bot.registry.registerGroup('misc', 'Misc.');
bot.registry.registerDefaults();
bot.registry.registerCommandsIn(__dirname + "/commands");

bot.login('MzEwMjU0ODMxODU4MDg5OTg1.DGmXXQ.7L6getcLt5sUvdWLtbex9yoxcDk');
